//
//  CustomCell.swift
//  Recovery Helper
//
//  Created by Mario Hernandez on 4/30/17.
//  Copyright © 2017 Mario Hernandez. All rights reserved.
//

import UIKit
import JTAppleCalendar

public class CustomCell: JTAppleCell {
    @IBOutlet weak var dateLabel: UILabel!
    @IBOutlet weak var selectedView: UIView!
    
    
    
}
